// CS370 Final Project
// Fall 2020

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"	// Sean Barrett's image loader - http://nothings.org/
#include <stdio.h>
#include <vector>
#include "vgl.h"
#include "objloader.h"
#include "utils.h"
#include "vmath.h"
#include "lighting.h"
#define DEG2RAD (M_PI/180.0)

using namespace vmath;
using namespace std;

enum VAO_IDs {Cube, Cylinder, Sphere,Bowl,TexCube,TexCylinder,Cone, NumVAOs};
enum Buffer_IDs {CubePosBuffer,CylinderPosBuffer, SpherePosBuffer,BowlPosBuffer, NumBuffers};

//light enums
enum ObjBuffer_IDs {PosBuffer, NormBuffer, NumObjBuffers, TexBuffer=1};
enum LightBuffer_IDs {LightBuffer, NumLightBuffers};
enum MaterialBuffer_IDs {MaterialBuffer, NumMaterialBuffers};
enum MaterialNames {Brass, RedPlastic, Glass, PaintedWalls, DeskMat, CompMat};

//texture enums
enum Textures {Wood,Carpet,Painting,SodaCan,Window,Computer, NumTextures};


GLuint VAOs[NumVAOs];
GLuint Buffers[NumBuffers];

//light buffer arrays
GLuint ObjBuffers[NumVAOs][NumObjBuffers];
GLuint LightBuffers[NumLightBuffers];
GLuint MaterialBuffers[NumMaterialBuffers];

//texture buffer arrays
GLuint TextureIDs[NumTextures];
GLuint MirrorTex;

GLint numVertices[NumVAOs];
GLint posCoords = 4;
GLint normCoords = 3;
GLint texCoords = 2;

//TODO: matrices for eventual mirror implementation
mat4 mirror_proj_matrix;
mat4 mirror_camera_matrix;

//connecting to texture files
vector<const char *> texFiles = {"../textures/wood.png", "../textures/carpet.png", "../textures/painting.jpeg",  "../textures/soda.png", "../textures/cloud.jpg", "../textures/computer3.png"};


//Light Shader variables
GLuint light_program;
GLuint light_vPos;
GLuint light_vNorm;
GLuint light_camera_mat_loc;
GLuint light_model_mat_loc;
GLuint light_proj_mat_loc;
GLuint light_norm_mat_loc;
GLuint lights_block_idx;
GLuint materials_block_idx;
GLuint material_loc;
GLuint num_lights_loc;
GLuint light_eye_loc;
GLuint light_on_loc;
const char *light_vertex_shader = "../phong.vert";
const char *light_frag_shader = "../phong.frag";

//lights on array
GLint ambientSwitch = 1;
GLint lightOn[8] = {ambientSwitch,0,1,1,1,1,1,1};

//texture shader variables
GLuint tex_program;
GLuint tex_proj_mat_loc;
GLuint tex_camera_mat_loc;
GLuint tex_model_mat_loc;
GLuint tex_vPos;
GLuint tex_vTex;
GLuint debug_mirror_program;

//texture shaders
const char *tex_vertex_shader = "../basicTex.vert";
const char *tex_frag_shader = "../basicTex.frag";
const char *debug_mirror_vertex_shader = "../debugMirror.vert";
const char *debug_mirror_frag_shader = "../debugMirror.frag";

vector<LightProperties> Lights;
vector<MaterialProperties> Materials;
GLuint MaterialIdx[NumVAOs] = {Brass, RedPlastic};
GLuint numLights;

mat4 normal_matrix;

vec4 cube_color = {1.0f, 0.0f, 0.0f,1.0f};
vec4 wall_color = {0.0f, 1.0f, 0.0f, 1.0f};
vec4 block_color = {0.0f, 0.0f, 1.0f, 1.0f};

// Camera
vec3 eye = {3.0f, 3.0f, 0.0f};
vec3 center = {0.0f, 0.0f, 0.0f};
vec3 up = {0.0f, 1.0f, 0.0f};

vec3 mirror_eye = {-8.55f, 3.0f, 0.0f};
vec3 mirror_center = {0.0f, 3.0f, 0.0f};
vec3 mirror_up = {0.0f, 1.0f, 0.0f};

// Shader variables for color mesh shaders
GLuint program;
GLuint vPos;
GLuint vCol;
GLuint model_mat_loc;
GLuint proj_mat_loc;
GLuint cam_mat_loc;
const char *vertex_shader = "../color_mesh.vert";
const char *frag_shader = "../color_mesh.frag";

// Global state
const char *models[NumVAOs] = {"../models/cube.obj" , "../models/cylinder.obj" , "../models/sphere.obj", "../models/bowl.obj", "../models/cube.obj", "../models/cylinder.obj", "../models/cone.obj"};

//orthographic matrices
mat4 proj_matrix;
mat4 camera_matrix;

//frustum matrices
mat4 frus_proj_matrix;
mat4 frus_camera_matrix;

//vectors for frustum camera
vec3 eye2 = {0.0f, 3.5f, 0.0f};
vec3 center2 = {0.0f, 3.5f, 1.0f};
vec3 up2 = {0.0f, 1.0f, 0.0f};
vec3 axis = {0.0f, 1.0f, 0.0f};

 //movement variables
 GLfloat dirx;
 GLfloat dirz;
GLfloat eye2x =0;
GLfloat eye2y = 0;
GLfloat eye2z = 0;
GLfloat lookUpDown = 0;
GLfloat moveDelta = 0;

// Global spherical coord values
GLfloat azimuth = 0.0f;
GLfloat daz = 0.1f;
GLfloat elevation = 90.0f;
GLfloat del = 2.0f;
GLfloat radius = 3.0f;
GLfloat dr = 0.1f;
GLfloat min_radius = 2.0f;

// Global screen dimensions
GLint ww,hh;

//TODO: animation variables
GLint blindFlag = 0;
GLfloat blindTheta = 0;
GLint fanFlag = 0;
GLfloat fanTheta = 0;
GLfloat switch1 = 125;
GLfloat switch2 = 125;
GLboolean compOn = false;

GLboolean mirror = false;

void build_geometry( );
void display( );
void render_scene( );
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods);
void mouse_callback(GLFWwindow *window, int button, int action, int mods);
void draw_obj(GLuint VAO, GLuint Buffer, int numVert);

//lighting functions
void draw_mat_object(GLuint obj);
void load_mat_object(GLuint obj);
void build_lights( );
void build_materials( );

//texture mapping functions
void load_tex_object(GLuint obj);
void draw_tex_object(GLuint obj);
void build_textures( );

//mirror functions
void build_mirror( );
void create_mirror( );
void render_mirror( );


int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Think Inside The Box");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

    // Store initial window size
    glfwGetFramebufferSize(window, &ww, &hh);

    // Register callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window,key_callback);
    glfwSetMouseButtonCallback(window, mouse_callback);

	// Create geometry buffers
    build_geometry();
    // Create light buffers
    build_lights();
    // Create material buffers
    build_materials();
    //create textures
    build_textures();
    //creat mirror texture
    build_mirror();

    
    // Load shaders and associate shader variables
	ShaderInfo shaders[] = { {GL_VERTEX_SHADER, vertex_shader},{GL_FRAGMENT_SHADER, frag_shader},{GL_NONE, NULL} };
	program = LoadShaders(shaders);
    vPos = glGetAttribLocation(program, "vPosition");
    vCol = glGetUniformLocation(program, "vColor");
    model_mat_loc = glGetUniformLocation(program, "model_matrix");
    proj_mat_loc = glGetUniformLocation(program, "proj_matrix");
    cam_mat_loc = glGetUniformLocation(program, "camera_matrix");

    //load light shader
    ShaderInfo light_shaders[] = { {GL_VERTEX_SHADER, light_vertex_shader},{GL_FRAGMENT_SHADER, light_frag_shader},{GL_NONE, NULL} };
    light_program = LoadShaders(light_shaders);

    // Select shader program and associate shader variables
    light_vPos = glGetAttribLocation(light_program, "vPosition");
    light_vNorm = glGetAttribLocation(light_program, "vNormal");
    light_camera_mat_loc = glGetUniformLocation(light_program, "cam_matrix");
    light_model_mat_loc = glGetUniformLocation(light_program, "model_matrix");
    light_proj_mat_loc = glGetUniformLocation(light_program, "proj_matrix");
    light_norm_mat_loc = glGetUniformLocation(light_program, "norm_matrix");
    lights_block_idx = glGetUniformBlockIndex(light_program, "LightBuffer");
    materials_block_idx = glGetUniformBlockIndex(light_program, "MaterialBuffer");
    material_loc = glGetUniformLocation(light_program, "Material");
    num_lights_loc = glGetUniformLocation(light_program, "NumLights");
    light_eye_loc = glGetUniformLocation(light_program, "EyePosition");
    light_on_loc = glGetUniformLocation(light_program, "LightOn");

    // Load tex shader
    ShaderInfo tex_shaders[] = { {GL_VERTEX_SHADER, tex_vertex_shader},{GL_FRAGMENT_SHADER, tex_frag_shader},{GL_NONE, NULL} };
    tex_program = LoadShaders(tex_shaders);

    // Select shader program and associate shader variables
    tex_vPos = glGetAttribLocation(tex_program, "vPosition");
    tex_vTex = glGetAttribLocation(tex_program, "vTexCoord");
    tex_model_mat_loc = glGetUniformLocation(tex_program, "model_matrix");
    tex_proj_mat_loc = glGetUniformLocation(tex_program, "proj_matrix");
    tex_camera_mat_loc = glGetUniformLocation(tex_program, "cam_matrix");

    //load mirror shader
    ShaderInfo debug_mirror_shaders[] = { {GL_VERTEX_SHADER, debug_mirror_vertex_shader},{GL_FRAGMENT_SHADER, debug_mirror_frag_shader},{GL_NONE, NULL} };
    debug_mirror_program = LoadShaders(debug_mirror_shaders);

    // Enable depth test
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.3f,0.3f,0.3f,1.0f);
    // Set Initial camera position
    GLfloat x, y, z;
    x = (GLfloat)(radius*sin(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    y = (GLfloat)(radius*cos(elevation*DEG2RAD));
    z = (GLfloat)(radius*cos(azimuth*DEG2RAD)*sin(elevation*DEG2RAD));
    eye = vec3(x, y, z);

    //enable blending
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {

        create_mirror();
        // Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();

        //blinds animations

        if(blindFlag != 0){
            if(blindFlag == 1 && blindTheta < 90) {
                blindTheta += blindFlag * 0.4f;
            }
            else if( blindFlag == -1 && blindTheta > 0){
                blindTheta += blindFlag * 0.4f;
            }
        }
        if(fanFlag != 0){
            fanTheta += 0.5f;
        }

        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void build_geometry( )
{

    // Model vectors
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    // Generate vertex arrays and buffers
    glGenVertexArrays(NumVAOs, VAOs);
    glGenBuffers(NumBuffers, Buffers);


    // Bind cube vertex array
    glBindVertexArray(VAOs[Cube]);

    // TODO: Load cube model and store number of vertices
    loadOBJ(models[Cube], vertices, uvCoords, normals);
    numVertices[Cube] = vertices.size();


    // Bind table vertex positions
    glBindBuffer(GL_ARRAY_BUFFER, Buffers[CubePosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[Cube], vertices.data(), GL_STATIC_DRAW);


    vertices.clear();
    uvCoords.clear();
    normals.clear();
    // Bind cube vertex array

    load_mat_object(Cube);

    load_mat_object(Cylinder);

    load_mat_object(Sphere);

    load_mat_object(Bowl);

    load_tex_object(TexCube);

    load_tex_object(TexCylinder);

    load_mat_object(Cone);

}

void build_lights( ) {
    // Spot white light
    LightProperties whiteSpotLight = {POINT, //type
                                      {0.0f, 0.0f, 0.0f}, //pad
                                      vec4(0.1f, 0.1f, 0.1f, 1.0f), //ambient
                                      vec4(1.0f, 1.0f, 1.0f, 1.0f), //diffuse
                                      vec4(1.0f, 1.0f, 1.0f, 1.0f), //specular
                                      vec4(0.0f, 5.0f, 0.0f, 1.0f),  //position
                                      vec4(-1.0f, -1.0f, -1.0f, 0.0f), //direction
                                      30.0f,   //cutoff
                                      20.0f,  //exponent
                                      {0.0f, 0.0f}  //pad2
    };

    LightProperties greenSpotLight = {SPOT, //type
                                      {0.0f, 0.0f, 0.0f}, //pad
                                      vec4(1.0f, 1.0f, 1.0f, 1.0f), //ambient
                                      vec4(1.0f, 1.0f, 1.0f, 1.0f), //diffuse
                                      vec4(1.0f, 1.0f, 1.0f, 1.0f), //specular
                                      vec4(5.5f, 5.75f, -5.25f, 1.0f),  //position
                                      vec4(0.0f, -1.0f, 0.0f, 0.0f), //direction
                                      15.0f,   //cutoff
                                      30.0f,  //exponent
                                      {0.0f, 0.0f}  //pad2
    };

    Lights.push_back(whiteSpotLight);
    Lights.push_back(greenSpotLight);

    numLights = Lights.size();

    glGenBuffers(NumLightBuffers, LightBuffers);
    glBindBuffer(GL_UNIFORM_BUFFER, LightBuffers[LightBuffer]);
    glBufferData(GL_UNIFORM_BUFFER, Lights.size()*sizeof(LightProperties), Lights.data(), GL_STATIC_DRAW);
}

void build_materials( ) {
    // Create brass material
    MaterialProperties brass = {vec4(0.33f, 0.22f, 0.03f, 1.0f), //ambient
                                vec4(0.78f, 0.57f, 0.11f, 1.0f), //diffuse
                                vec4(0.99f, 0.91f, 0.81f, 1.0f), //specular
                                27.8f, //shininess
                                {0.0f, 0.0f, 0.0f}  //pad
    };

    // Create red plastic material
    MaterialProperties redPlastic = {vec4(0.3f, 0.0f, 0.0f, 1.0f), //ambient
                                     vec4(0.6f, 0.0f, 0.0f, 1.0f), //diffuse
                                     vec4(0.8f, 0.6f, 0.6f, 1.0f), //specular
                                     32.0f, //shininess
                                     {0.0f, 0.0f, 0.0f}  //pad
    };

    MaterialProperties Glass = {vec4(1.0f, 1.0f, 1.0f, 0.8f), //ambient
                                     vec4(1.0f, 1.0f, 1.0f, 0.8f), //diffuse
                                     vec4(1.0f, 1.0f, 1.0f, 0.8f), //specular
                                     32.0f, //shininess
                                     {0.0f, 0.0f, 0.0f}  //pad
    };

    MaterialProperties PaintedWalls = {
            vec4(0.25f, 0.20725f, 0.20725f, 1.0f),
            vec4(1.0f, 0.829f, 0.829f, 1.0f ),
            vec4(0.296648f, 0.296648f, 0.296648f, 1.0f ),
            11.264f,
            {0.0f, 0.0f, 0.0f}  //pad

    };

    MaterialProperties DeskMat = {
            vec4(0.05375f, 0.05f, 0.06625f, 0.82f ),
            vec4(.18275f, 0.17f, 0.22525f, 0.82f),
            vec4(0.332741f, 0.328634f, 0.346435f, 0.82f),
            38.4f,
            {0.0f, 0.0f, 0.0f}  //pad
    };

    MaterialProperties compMat = {
            vec4(0.23125f, 0.23125f, 0.23125f, 1.0f ),
            vec4(0.2775f, 0.2775f, 0.2775f, 1.0f),
            vec4(0.773911f, 0.773911f, 0.773911f, 1.0f ),
            89.6f,
            {0.0f, 0.0f, 0.0f}  //pad
    };

    // Add materials to Materials vector
    Materials.push_back(brass);
    Materials.push_back(redPlastic);
    Materials.push_back(Glass);
    Materials.push_back(PaintedWalls);
    Materials.push_back(DeskMat);
    Materials.push_back(compMat);

    glGenBuffers(NumMaterialBuffers, MaterialBuffers);
    glBindBuffer(GL_UNIFORM_BUFFER, MaterialBuffers[MaterialBuffer]);
    glBufferData(GL_UNIFORM_BUFFER, Materials.size()*sizeof(MaterialProperties), Materials.data(), GL_STATIC_DRAW);
}

// build textures
void build_textures( ) {
    int w, h, n;
    int force_channels = 4;
    unsigned char *image_data;

    // Create textures and activate unit 0
    glGenTextures( NumTextures,  TextureIDs);
    glActiveTexture( GL_TEXTURE0 );

    for (int i = 0; i < NumTextures; i++) {
        // Load image from file
        image_data = stbi_load(texFiles[i], &w, &h, &n, force_channels);
        if (!image_data) {
            fprintf(stderr, "ERROR: could not load %s\n", texFiles[i]);
        }
        // NPOT check for power of 2 dimensions
        if ((w & (w - 1)) != 0 || (h & (h - 1)) != 0) {
            fprintf(stderr, "WARNING: texture %s is not power-of-2 dimensions\n",
                    texFiles[i]);
        }
        int width_in_bytes = w * 4;
        unsigned char *top = NULL;
        unsigned char *bottom = NULL;
        unsigned char temp = 0;
        int half_height = h / 2;

        for ( int row = 0; row < half_height; row++ ) {
            top = image_data + row * width_in_bytes;
            bottom = image_data + ( h - row - 1 ) * width_in_bytes;
            for ( int col = 0; col < width_in_bytes; col++ ) {
                temp = *top;
                *top = *bottom;
                *bottom = temp;
                top++;
                bottom++;
            }
        }

        // TODO: Bind current texture id
        glBindTexture(GL_TEXTURE_2D, TextureIDs[i]);
        // TODO: Load image data into texture
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                     image_data);
        glGenerateMipmap(GL_TEXTURE_2D);
        // TODO: Set scaling modes
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        // TODO: Set wrapping modes
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set maximum anisotropic filtering for system
        GLfloat max_aniso = 0.0f;
        glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &max_aniso);
        // set the maximum!
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, max_aniso);
    }
}

void build_mirror( ) {
    glGenTextures(1, &MirrorTex);
    glBindTexture(GL_TEXTURE_2D, MirrorTex);
    // TODO: Create mirror texture
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ww, hh, 0, GL_RGBA, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
}

void create_mirror( ) {
    // Clear framebuffer for mirror rendering pass
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // TODO: Set mirror projection matrix
    frus_proj_matrix = frustum(-0.2f, 0.2f, -0.2f, 0.2f, 0.2f, 100.0f);

    // TODO: Set mirror camera matrix
    frus_camera_matrix = lookat(mirror_eye, mirror_center, mirror_up);

    // Render mirror scene (without mirror)
    mirror = true;
    render_scene();
    glFlush();
    mirror = false;

    // TODO: Bind mirror texture and copy framebuffer
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, MirrorTex);
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 0, 0, ww, hh, 0);
}

void render_mirror( ) {
    mat4 trans_matrix;
    mat4 rot_matrix;
    mat4 scale_matrix;
    mat4 model_matrix;

    // Use texture shader
    glUseProgram(tex_program);
    glUniformMatrix4fv(tex_proj_mat_loc, 1, GL_FALSE, frus_proj_matrix);
    glUniformMatrix4fv(tex_camera_mat_loc, 1, GL_FALSE, frus_camera_matrix);
    // TODO: Bind environment map
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, MirrorTex);
    // TODO: Set mirror translation
    trans_matrix = translate(vec3(-9.5f, 4.0f, 0.0f));
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(3.0f, 3.0f, 3.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    model_matrix = trans_matrix * rot_matrix  * scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    // TODO: Draw mirror
    draw_tex_object(TexCube);
}

void display( )
{
    // Declare projection and camera matrices for orthographic
    proj_matrix = mat4().identity();
    camera_matrix = mat4().identity();

    //declare matrices for projection view
    frus_camera_matrix = mat4().identity();
    frus_proj_matrix = mat4().identity();

	// Clear window and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Compute anisotropic scaling
    GLfloat xratio = 1.0f;
    GLfloat yratio = 1.0f;
    // If taller than wide adjust y
    if (ww <= hh)
    {
        yratio = (GLfloat)hh / (GLfloat)ww;
    }
        // If wider than tall adjust x
    else if (hh <= ww)
    {
        xratio = (GLfloat)ww / (GLfloat)hh;
    }

    // TODO: Set perspective projection matrix
    proj_matrix = ortho(-15.0f*xratio, 15.0f*xratio, -15.0f*yratio, 15.0f*yratio, -15.0f, 15.0f);

    //set frustum matrix values

    frus_proj_matrix = frustum(-1.0f*xratio, 1.0f*xratio, -1.0f*yratio, 1.0f*yratio, 0.75f, 100.0f);

    // TODO: Set camera matrix
    camera_matrix = lookat(eye, center, up);

    //frustum camera matrix
    frus_camera_matrix = lookat(eye2, center2, up2);


    // Render objects
	render_scene();

	// Flush pipeline
	glFlush();
}

void render_scene( ) {
    // Declare transformation matrices
    mat4 model_matrix = mat4().identity();
    mat4 scale_matrix = mat4().identity();
    mat4 rot_matrix = mat4().identity();
    mat4 trans_matrix = mat4().identity();
    mat4 rot_matrix2 = mat4().identity();

    glUseProgram(light_program);
    glUniformMatrix4fv(light_proj_mat_loc, 1, GL_FALSE, frus_proj_matrix);
    glUniformMatrix4fv(light_camera_mat_loc, 1, GL_FALSE, frus_camera_matrix);

    // Bind lights
    glUniformBlockBinding(light_program, lights_block_idx, 0);
    glBindBufferRange(GL_UNIFORM_BUFFER, 0, LightBuffers[LightBuffer], 0, Lights.size() * sizeof(LightProperties));

    // Bind materials
    glUniformBlockBinding(light_program, materials_block_idx, 1);
    glBindBufferRange(GL_UNIFORM_BUFFER, 1, MaterialBuffers[MaterialBuffer], 0,
                      Materials.size() * sizeof(MaterialProperties));
    // Set eye position
    glUniform3fv(light_eye_loc, 1, eye2);

    glUniform1i(num_lights_loc, numLights);
    glUniform1iv(light_on_loc, numLights, lightOn);



    //draw first wall with lighting
    trans_matrix = translate(0.0f, 2.0f, -7.75f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    rot_matrix2 = rotate(90.0f, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(8.0f, 1.0f, 8.0f);
    model_matrix = trans_matrix*rot_matrix2*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw second wall with lighting
    trans_matrix = translate(0.0f, 2.0f, 7.75f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    rot_matrix2 = rotate(90.0f, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(8.0f, 1.0f, 8.0f);
    model_matrix = trans_matrix*rot_matrix2*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw third wall with lighting
    trans_matrix = translate(-7.75f, 2.0f, 0.0f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(8.0f, 1.0f, 8.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw fourth wall with lighting
    trans_matrix = translate(7.75f, 2.0f, 0.0f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(8.0f, 1.0f, 8.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw lit ceiling
    trans_matrix = translate(0.0f, 10.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(8.0f, 0.25f, 8.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);


    //draw the cylinder by the door knob
    trans_matrix = translate(-1.0f, 1.5f, -8.5f);
    rot_matrix = rotate(-90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.35f, 2.0f, 0.35f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //draw the doorknob
    trans_matrix = translate(-1.0f, 1.5f, -6.25f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw the liquid in the glass
    trans_matrix = translate(1.0f, 0.15f, 2.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.15f, 0.8f, 0.15f);
    model_matrix = trans_matrix * rot_matrix * scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, RedPlastic);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //draw  a piece of fruit #1
    trans_matrix = translate(0.0f, 0.75f, 4.0f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw a piece of fruit #2
    trans_matrix = translate(0.0f, 0.65f, 4.35f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw a piece of fruit #3
    trans_matrix = translate(0.0f, 0.65f, 3.45f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw a piece of fruit #4
    trans_matrix = translate(0.35f, 0.65f, 4.0f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw a piece of fruit #5
    trans_matrix = translate(-0.35f, 0.65f, 4.0f);
    rot_matrix = rotate(90.0f, vec3(1.0f, 0.0f, 0.0f));
    scale_matrix = scale(0.3f, 0.3f, 0.3f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);



    //draw the blinds
    for(int i = 0; i<16; i++) {
        trans_matrix = translate(3.75f-(i*0.5f), 4.25f, 6.25f);
        rot_matrix = rotate(blindTheta, vec3(0.0f, 1.0f, 0.0f));
        scale_matrix = scale(0.05f, 3.0f, 0.25f);
        model_matrix = trans_matrix * rot_matrix * scale_matrix;
        normal_matrix = model_matrix.inverse().transpose();
        glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
        glUniform1i(material_loc, CompMat);
        glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
        draw_mat_object(Cube);
    }

    //draw cylinder connecting light to the ceiling
    trans_matrix = translate(0.0f, 10.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.25f, 1.75f, 0.25f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //draw light part of the ceiling fan
    trans_matrix = translate(0.0f, 8.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.5f, 0.5f, 0.5f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Brass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Sphere);

    //draw light plate
    trans_matrix = translate(3.5f, 3.5f, -7.15f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.5f, 0.5f, 0.5f);
    model_matrix = trans_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //cylinder part of light switch 1
    model_matrix = mat4().identity();
    trans_matrix = translate(3.25f, 3.5f, -6.75f);
    scale_matrix = scale(0.15f, 0.05f, 0.15f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //cylinder part of light switch 7
    model_matrix = mat4().identity();
    trans_matrix = translate(3.75f, 3.5f, -6.75f);
    scale_matrix = scale(0.15f, 0.05f, 0.15f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //draw switch 1
    trans_matrix = translate(3.75f, 3.5f, -6.75f);
    scale_matrix = scale(0.05f, 0.25f, 0.05f);
    rot_matrix = rotate(switch1, vec3(1.0f, 0.0f, 0.0f));
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw switch 2
    trans_matrix = translate(3.25f, 3.5f, -6.75f);
    scale_matrix = scale(0.05f, 0.25f, 0.05f);
    rot_matrix = rotate(switch2, vec3(1.0f, 0.0f, 0.0f));
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, PaintedWalls);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw left desk leg
    trans_matrix = translate(6.25f, -2.0f, -6.5f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(1.0f, 2.0f, 0.25f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw right desk leg
    trans_matrix = translate(6.25f, -2.0f, -3.5f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(1.0f, 2.0f, 0.25f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw the desk top
    trans_matrix = translate(6.75f, 0.0f, -5.25f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(2.0f, 0.05f, 2.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw bottom of laptop
    trans_matrix = translate(5.5f, 0.15f, -5.25f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.5f, 0.05f, 1.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, CompMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw top of laptop
    trans_matrix = translate(6.2f, 0.95f, -5.25f);
    rot_matrix = rotate(75.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.75f, 0.05f, 1.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, CompMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cube);

    //draw lamp wire
    trans_matrix = translate(5.5f, 9.75f, -5.25f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.05f, 4.0f, 0.05f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cylinder);

    //draw lamp head
    trans_matrix = translate(5.5f, 5.75f, -5.25f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.5f, 0.75f, 0.5f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniform1i(material_loc, DeskMat);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    draw_mat_object(Cone);

    //draw black screen if off
    if(!compOn) {
        trans_matrix = translate(6.18f, 0.95f, -5.25f);
        rot_matrix = rotate(75.0f, vec3(0.0f, 0.0f, 1.0f));
        scale_matrix = scale(0.65f, 0.05f, 0.85f);
        model_matrix = trans_matrix * rot_matrix * scale_matrix;
        glUniform1i(material_loc, DeskMat);
        glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
        draw_mat_object(Cube);
    }
    //TODO: objects with transparency

    //draw the bowl for the fruit
    trans_matrix = translate(0.0f, 1.0f, 4.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(1.0f, 1.0f, 1.0f);
    model_matrix = trans_matrix * rot_matrix * scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Glass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    glDepthMask(GL_FALSE);
    draw_mat_object(Bowl);
    glDepthMask(GL_TRUE);

    //draw a glass on the table
    trans_matrix = translate(1.0f, 0.0f, 2.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.25f, 1.0f, 0.25f);
    model_matrix = trans_matrix * rot_matrix * scale_matrix;
    glUniformMatrix4fv(light_norm_mat_loc, 1, GL_FALSE, normal_matrix);
    glUniform1i(material_loc, Glass);
    glUniformMatrix4fv(light_model_mat_loc, 1, GL_FALSE, model_matrix);
    glDepthMask(GL_FALSE);
    draw_mat_object(Cylinder);
    glDepthMask(GL_TRUE);

    //TODO: draw textured objects

    //select the texture shader and pass its variables
    glUseProgram(tex_program);
    glUniformMatrix4fv(tex_proj_mat_loc, 1, GL_FALSE, frus_proj_matrix);
    glUniformMatrix4fv(tex_camera_mat_loc, 1, GL_FALSE, frus_camera_matrix);


    model_matrix = mat4().identity();
    //draw door
    trans_matrix = translate(0.0f, 1.75f, -8.65f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(2.0f, 4.5f, 2.0f);
    model_matrix = trans_matrix*scale_matrix;
    normal_matrix = model_matrix.inverse().transpose();
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw carpeted floor
    trans_matrix = translate(0.0f, -3.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(8.0f, 0.25f, 8.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Carpet]);
    draw_tex_object(TexCube);

    //draw textured legs of the table
    for(int i = 0; i<2; i++) {
        trans_matrix = translate(2.0f * i, -2.0f, 0.0f);
        rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
        scale_matrix = scale(0.25f, 1.5f, 0.25f);
        model_matrix = trans_matrix * rot_matrix * scale_matrix;
        glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
        glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
        draw_tex_object(TexCube);
    }

    //other side of table legs
    for(int i = 0; i<2; i++) {
        trans_matrix = translate(2.0f * i, -2.0f, 4.0f);
        rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
        scale_matrix = scale(0.25f, 1.5f, 0.25f);
        model_matrix = trans_matrix * rot_matrix * scale_matrix;
        glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
        glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
        draw_tex_object(TexCube);
    }

    //draw the tabletop
    trans_matrix = translate(1.0f, -0.5f, 2.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(1.75f, 0.15f, 3.0f);
    model_matrix = trans_matrix * rot_matrix * scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw fourth wall painting
    trans_matrix = translate(9.65f, 4.0f, 0.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(3.0f, 3.0f, 3.0f);
    model_matrix = trans_matrix*rot_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Painting]);
    draw_tex_object(TexCube);

    //draw first fan blade
    trans_matrix = translate(1.5f, 8.0f, 0.0f);
    rot_matrix = rotate(fanTheta, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(1.5f, 0.05f, 0.5f);
    model_matrix = rot_matrix*trans_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw second fan blade
    trans_matrix = translate(1.5f, 8.0f, 0.0f);
    rot_matrix = rotate(fanTheta+120, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(1.5f, 0.05f, 0.5f);
    model_matrix = rot_matrix*trans_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw third fan blade
    trans_matrix = translate(1.5f, 8.0f, 0.0f);
    rot_matrix = rotate(fanTheta+240, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(1.5f, 0.05f, 0.5f);
    model_matrix = rot_matrix*trans_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw textured legs of the table
    for(int i = 0; i<2; i++) {
        trans_matrix = translate(-2.0f - (i*1.0f), -2.0f, 1.5f);
        rot_matrix = rotate(15.0f, vec3(0.0f, 1.0f, 0.0f));
        scale_matrix = scale(0.15f, 1.0f, 0.15f);
        model_matrix =  rot_matrix * trans_matrix * scale_matrix;
        glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
        glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
        draw_tex_object(TexCube);
    }

    //other side of table legs
    for(int i = 0; i<2; i++) {
        trans_matrix = translate(-2.0f - (i*1.0f), -2.0f, 2.5f);
        rot_matrix = rotate(15.0f, vec3(0.0f, 1.0f, 0.0f));
        scale_matrix = scale(0.15f, 1.0f, 0.15f);
        model_matrix =  rot_matrix * trans_matrix * scale_matrix;
        glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
        glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
        draw_tex_object(TexCube);
    }

    //chair seat part
    trans_matrix = translate(-2.5f , -1.0f, 2.0f);
    rot_matrix = rotate(15.0f, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(1.0f, 0.05f, 1.0f);
    model_matrix =  rot_matrix * trans_matrix * scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //chair back part
    rot_matrix2 = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));

    trans_matrix = translate(-3.45f , 0.5f, 2.0f);
    rot_matrix = rotate(15.0f, vec3(0.0f, 1.0f, 0.0f));
    scale_matrix = scale(1.5f, 0.05f, 1.0f);
    model_matrix =  rot_matrix * trans_matrix * rot_matrix2 * scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    trans_matrix = translate(1.0f, 0.0f, 1.0f);
    rot_matrix = rotate(0.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(0.125f, 0.5f, 0.125f);
    model_matrix = trans_matrix * rot_matrix * scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[SodaCan]);
    draw_tex_object(TexCylinder);

    //draw the window
    trans_matrix = translate(0.0f, 4.0f, 8.65f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(4.0f, 3.0f, 2.0f);
    model_matrix = trans_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Window]);
    draw_tex_object(TexCube);

    //draw the blinds holder
    trans_matrix = translate(0.0f, 8.0f, 8.25f);
    rot_matrix = rotate(90.0f, vec3(0.0f, 0.0f, 1.0f));
    scale_matrix = scale(4.0f, 0.5f, 2.0f);
    model_matrix = trans_matrix*scale_matrix;
    glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
    glBindTexture(GL_TEXTURE_2D, TextureIDs[Wood]);
    draw_tex_object(TexCube);

    //draw computer screen if on
    if(compOn) {
        trans_matrix = translate(6.18f, 0.95f, -5.25f);
        rot_matrix = rotate(75.0f, vec3(0.0f, 0.0f, 1.0f));
        scale_matrix = scale(0.65f, 0.05f, 0.85f);
        model_matrix = trans_matrix * rot_matrix * scale_matrix;
        glUniformMatrix4fv(tex_model_mat_loc, 1, GL_FALSE, model_matrix);
        glBindTexture(GL_TEXTURE_2D, TextureIDs[Computer]);
        draw_tex_object(TexCube);
    }
    if (!mirror) {

        // Render mirror in scene
        render_mirror();
    }
}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods) {
    // ESC to quit
    if (key == GLFW_KEY_ESCAPE) {
        glfwSetWindowShouldClose(window, true);
    }
    else if(key == GLFW_KEY_W){
        if(eye2x > -5.75f && eye2x < 5.75f && eye2z > -5.75f && eye2z < 5.75f) {
            moveDelta = 0.1f;
            eye2x = eye2x + dirx * moveDelta;
            eye2z = eye2z + dirz * moveDelta;
        }
        else{
            moveDelta = -0.2f;
            eye2x = eye2x + dirx * moveDelta;
            eye2z = eye2z + dirz * moveDelta;
        }
        moveDelta = 0;
    }
    else if(key == GLFW_KEY_S ){
        if(eye2x > -5.75f && eye2x < 5.75f && eye2z > -5.75f && eye2z < 5.75f) {
            moveDelta = -0.1f;
            eye2x = eye2x + dirx * moveDelta;
            eye2z = eye2z + dirz * moveDelta;
        }
        else{
            moveDelta = 0.2f;
            eye2x = eye2x + dirx * moveDelta;
            eye2z = eye2z + dirz * moveDelta;
        }
        moveDelta = 0;
    }
    // Adjust azimuth
    else if (key == GLFW_KEY_D) {
        azimuth += daz;

    } else if (key == GLFW_KEY_A) {
        azimuth -= daz;

    }
    else if (key == GLFW_KEY_Z) {
        if(lookUpDown < 10) {
            lookUpDown += 0.1;
        }
        else{

        }

    }
    else if (key == GLFW_KEY_X) {
        if(lookUpDown > -2.0f) {
            lookUpDown -= 0.1;
        }
        else{

        }

    }
    else if(key == GLFW_KEY_O && action == GLFW_PRESS){
        if(blindFlag != 1){
            blindFlag = 1;
        }
        else{
            blindFlag = -1;
        }
    }
    else if(key == GLFW_KEY_F && action == GLFW_PRESS){
        if(fanFlag != 1){
            fanFlag = 1;
        }
        else{
            fanFlag = 0;
        }
        if(switch1 == 125){
            switch1 = 75;
        }
        else{
            switch1 = 125;
        }
    }
    else if(key == GLFW_KEY_L && action == GLFW_PRESS){
        if(switch2 == 125){
            switch2 = 75;
        }
        else{
            switch2 = 125;
        }
        if(lightOn[1] == 1){
            lightOn[1] = 0;
        }
        else{
            lightOn[1] = 1;
        }
    }
    else if(key == GLFW_KEY_C && action == GLFW_PRESS){
        if(!compOn){
            compOn = true;
        }
        else{
            compOn = false;
        }
    }



   //compute updated frustum values
    //set frustum camera position values



    //set frustum camera aim values

    GLfloat center2x, center2y, center2z;
    center2x = eye2x + cos(azimuth);
    center2y = eye2y + lookUpDown;
    center2z = eye2z + sin(azimuth);

    dirx = center2x - eye2x;
    dirz = center2z - eye2z;

    eye2x = eye2x +dirx* moveDelta;
    eye2y = 3.5f;
    eye2z = eye2z + dirz * moveDelta;

    eye2 = vec3(eye2x, eye2y, eye2z);
    center2 = vec3(center2x, center2y, center2z);


}

void mouse_callback(GLFWwindow *window, int button, int action, int mods){

}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);

    ww = width;
    hh = height;
}

//lighting specific function definitions
void draw_mat_object(GLuint obj){
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(light_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(light_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][NormBuffer]);
    glVertexAttribPointer(light_vNorm, normCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(light_vNorm);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);

}

void load_mat_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    loadOBJ(models[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();
    // Create and load object buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][NormBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*normCoords*numVertices[obj], normals.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void draw_obj(GLuint VAO, GLuint Buffer, int numVert) {
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, Buffer);
    glVertexAttribPointer(vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(vPos);
    glDrawArrays(GL_TRIANGLES, 0, numVert);
}

//TODO: texture loader and drawer functions

void load_tex_object(GLuint obj) {
    vector<vec4> vertices;
    vector<vec2> uvCoords;
    vector<vec3> normals;

    loadOBJ(models[obj], vertices, uvCoords, normals);
    numVertices[obj] = vertices.size();
    // Create and load object buffers
    glGenBuffers(NumObjBuffers, ObjBuffers[obj]);
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*posCoords*numVertices[obj], vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*texCoords*numVertices[obj], uvCoords.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

}

void draw_tex_object(GLuint obj){
    glBindVertexArray(VAOs[obj]);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][PosBuffer]);
    glVertexAttribPointer(tex_vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(tex_vPos);
    glBindBuffer(GL_ARRAY_BUFFER, ObjBuffers[obj][TexBuffer]);
    glVertexAttribPointer(tex_vTex, texCoords, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(tex_vTex);
    glDrawArrays(GL_TRIANGLES, 0, numVertices[obj]);
}